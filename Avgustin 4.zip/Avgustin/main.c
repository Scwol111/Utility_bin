#include "philo.h"

t_count  init(void)
{
    t_count count;

    count.philo = -1;
    count.eating = -1;
    count.sleeping = -1;
    count.dying = -1;
    count.death = 0;
    count.serving_size = -1;
    count.serving_count = -1;
    return (count);

}

int test(t_philo *philo)
{
    if(philo->count.philo <= 0)
        return printf("Need Augustine Avreliy");
    if (philo->count.dying < 1)
        return printf("Wrong input");
    if (philo->count.eating < 1)
        return printf("Wrong input");
    if (philo->count.sleeping < 1)
        return printf("Wrong input");
    return (0);
}

int pull(t_philo *philo, char **av)
{
    t_count count;
    count = init();
    count.philo = atoi(av[1]);
    count.dying = atoi(av[2]);
    count.eating = atoi(av[3]);
    count.sleeping = atoi(av[4]);
    if(av[5]) {
        count.serving_count = atoi(av[5]);
        count.serving_size = count.philo * count.eating;
    }
    philo->count = count;
    return (test(philo));
}

void	clean(t_philo *philo)
{
    int	i;

    i = -1;
  //  while (++i < philo->count.philo)
   //     pthread_detach(philo[i].thread);
   // pthread_detach(philo->count.fatal);
    if (philo->count.forks)
    {
        pthread_mutex_destroy(philo->count.forks);
        free(philo->count.forks);
    }
//    if (philo)
//        free(philo);
//    philo->count.forks = NULL;
//    philo = NULL;
//    free(philo);
}


int main(int ac, char** av) {
    t_philo philo;
       if (ac != 5)
    {
        printf("Wrong number of arguments");
        return (1);
    }
    if (pull(&philo, av))
        return (1);
    if(alloc(&philo))
        return (1);
    build(&philo);
    clean(&philo);
    return 0;
}
