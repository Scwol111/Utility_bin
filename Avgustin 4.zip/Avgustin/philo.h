#ifndef PHILO_H
#define PHILO_H
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
# include <sys/time.h>

typedef struct s_count
{
    int         philo;

    int         eating;
    int         sleeping;
    int         dying;
    int         death;
    int         serving_size;
    int         serving_count;
    pthread_mutex_t	*forks;
    pthread_mutex_t	some;
    pthread_t       fatal;
    unsigned long	timedot;

}			   t_count;



typedef struct s_philo
{    int id;
    int l_fork;
    int r_fork;
    unsigned long   branch;
    pthread_t *thread;
    unsigned int frag;
    t_count			count;
    int             error;

}			   t_philo;

int build(t_philo *philo);
unsigned	long	get_time(void);
void	view(char *str, t_philo *philo);
void	*live(void *live);
int	 alloc(t_philo *philo);

#endif
