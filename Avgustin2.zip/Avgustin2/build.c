#include "philo.h"

unsigned	long	get_time(void)
{
    struct timeval	jikan;

    gettimeofday(&jikan, NULL);
    return ((jikan.tv_sec * (unsigned long)1000) + (jikan.tv_usec / 1000));
}



int	branch(t_philo *philo, int i)
{
    philo->count.forks = malloc(sizeof ( pthread_mutex_t*) * philo->count.philo);
    pthread_mutex_init(&philo->count.forks[i], NULL);
    philo->frag = 0;
    philo[i].branch = 0;
    philo[i].l_fork = i;
    philo[i].r_fork = (i + 1) % philo->count.philo;
    philo[i].count = philo->count;
    philo[i].count.timedot = get_time();
   philo[i].id = i + 1;
    pthread_create(&philo[i].thread, NULL, &live,&philo[i]);
//    if (pthread_create(&philo[i].thread, NULL, &live,&philo[i]))
//    {
//        printf("PTHREAD create\n");
//        philo->frag = 1;
//    }
    pthread_detach(philo[i].thread);
    return ( philo->frag);
}

void	*fatal(void *tmp)
{
    int				i;
    t_philo			*philo;
    long int		time_to_dye;

    philo = (t_philo *)tmp;
    while (1)
    {
        i = -1;
        while (++i < philo->count.philo)
        {
            time_to_dye = get_time() - philo[i].branch;
            if (philo->count.dying < time_to_dye)
            {
                view("FATALITY", &philo[i]);
                philo->count.death = 1;
                return (NULL);
            }
        }
    }
}

int build(t_philo *philo) {
    int i;

    i = -1;
    while (++i < philo->count.philo)
    {
        if (branch(philo, i))
           return (1);}
  //  if ((pthread_create(&philo->count.fatal, NULL, fatal, (void *) philo)) != 0) {
    //    printf("No pthread");
     //   return (1);
   // }
   // pthread_join(philo->count.fatal, NULL);
    fatal(philo);
   return (0);
}