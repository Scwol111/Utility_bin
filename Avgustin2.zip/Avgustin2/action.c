#include "philo.h"

int	eat(t_philo *philo)
{
    pthread_mutex_lock(&philo->count.forks[philo->l_fork]);
    view("Taken a l_fork\n", philo);
    pthread_mutex_lock(&philo->count.forks[philo->r_fork]);
    view("Taken a r_fork\n", philo);
    view("Eating pasta\n", philo);
    if (philo->count.serving_size > -1)
    {
        if (philo->count.serving_size == 0)
            return (1);
        philo->count.serving_size--;
    }
    philo->branch = get_time();
    usleep(philo->count.eating * 1000);
    pthread_mutex_unlock(&philo->count.forks[philo->l_fork]);
    pthread_mutex_unlock(&philo->count.forks[philo->r_fork]);
    return (0);
}


int	sleeping(t_philo *philo)
{
    if (eat(philo))
        return (1);
    view("Sleeping\n", philo);
    usleep(philo->count.sleeping * 1000);
    view("Thinking\n", philo);
    return (0);
}

void	view(char *str, t_philo *philo)
{
    long long int	jikan;

    if (!philo->count.death && philo->count.serving_size != 0)
    {
        jikan = get_time() - philo->count.timedot;
        pthread_mutex_lock(&philo->count.some);
        printf("%lld %d %s\n", jikan, philo->id, str);
        pthread_mutex_unlock(&philo->count.some);
    }
}


void	*live(void *live)
{
    int			i;
    t_philo	*philo;

    i = 1;
    philo = (t_philo *)live;
//    pthread_detach(philo->thread);
    if (philo->l_fork % 2 == 0)
        usleep(philo->count.eating * 1000);
    while (1)
        if (sleeping(philo))
            break ;
    return (NULL);
}
